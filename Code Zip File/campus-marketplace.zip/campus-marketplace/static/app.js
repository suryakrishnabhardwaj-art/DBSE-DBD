const $ = (s, r = document) => r.querySelector(s);
const el = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; };
const app = $("#app");
let user = null, nodes = [], cart = {}, timer = null, products = [];

async function api(path, method = "GET", body) {
  const r = await fetch("/api" + path, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { toast(data.error || "Request failed"); throw new Error(data.error); }
  return data;
}
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.style.display = "block"; clearTimeout(t._h); t._h = setTimeout(() => t.style.display = "none", 2600); }
const inr = (n) => "₹" + Number(n).toFixed(2);
const opts = (arr, sel) => arr.map(n => `<option ${n === sel ? "selected" : ""}>${n}</option>`).join("");
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function boot() {
  nodes = (await api("/map")).nodes;
  user = (await api("/me")).user;
  render();
}
function render() {
  clearInterval(timer);
  $("#who").innerHTML = user ? `${esc(user.name)} (${user.role}) <button class="sec" id="lo">Logout</button>` : "";
  if (user) $("#lo").onclick = async () => { await api("/logout", "POST"); user = null; cart = {}; render(); };
  app.innerHTML = "";
  ({ customer: customerView, vendor: vendorView, delivery: deliveryView, admin: adminView }[user?.role] || authView)();
}

// ---------------------------------------------------------------- auth
function authView() {
  const c = el(`<div class="two"><div class="card"><h2>Login</h2>
    <div class="row"><input id="le" placeholder="Email" value="student@campus.edu"><input id="lp" type="password" placeholder="Password" value="student123"><button id="lb">Login</button></div>
    <p class="mute">Demo: student@campus.edu/student123 · canteen@campus.edu/vendor123 · rider1@campus.edu/rider123 · admin@campus.edu/admin123</p></div>
    <div class="card"><h2>Register</h2>
    <div class="row"><select id="rr"><option value="customer">Customer</option><option value="vendor">Vendor</option><option value="delivery">Delivery partner</option></select></div>
    <div class="row"><input id="rn" placeholder="Name"><input id="re" placeholder="Email"><input id="rp" type="password" placeholder="Password (min 6)"></div>
    <div class="row" id="extra"></div><button id="rb">Register</button></div></div>`);
  app.append(c);
  const extra = () => {
    const r = $("#rr").value;
    $("#extra").innerHTML = r === "customer" ? "" : `${r === "vendor" ? '<input id="rs" placeholder="Shop name"><select id="rc"><option>Food</option><option>Grocery</option><option>Stationery</option><option>Pharmacy</option><option>Other</option></select>' : ""}<select id="rno">${opts(nodes)}</select>`;
  };
  $("#rr").onchange = extra; extra();
  $("#lb").onclick = async () => { user = await api("/login", "POST", { email: $("#le").value, password: $("#lp").value }); render(); };
  $("#rb").onclick = async () => {
    const role = $("#rr").value;
    await api("/register", "POST", { role, name: $("#rn").value, email: $("#re").value, password: $("#rp").value, node: $("#rno")?.value, shop_name: $("#rs")?.value, category: $("#rc")?.value });
    toast("Registered! Please log in."); $("#le").value = $("#re").value; $("#lp").value = $("#rp").value;
  };
}

// ---------------------------------------------------------------- customer
function orderCard(o, extra = "") {
  const r = o.route ? `<div class="route">🧭 ${o.route.path.join(" → ")}<br>${o.route.total_m} m · ETA ~${o.route.eta_min} min</div>` : "";
  return `<div class="item"><div><b>#${o.id}</b> ${esc(o.shop_name)} <span class="tag ${o.status}">${o.status}</span>${o.express ? " ⚡" : ""}</div>
    <div class="mute">${o.items.map(i => `${i.qty}× ${esc(i.name)}`).join(", ")}</div>
    <div>${inr(o.total)} · ${o.payment_method} (${o.payment_status}) · to ${esc(o.delivery_node)}</div>${r}${extra}</div>`;
}
function customerView() {
  const v = el(`<div class="two"><div class="card"><h2>Browse products</h2>
    <div class="row"><input id="q" list="sg" placeholder="Search (e.g. noo, pen, water)"><datalist id="sg"></datalist>
    <select id="cat"><option value="">All categories</option><option>Food</option><option>Grocery</option><option>Stationery</option><option>Pharmacy</option></select>
    <input id="mx" type="number" placeholder="Max ₹" style="width:90px">
    <select id="sort"><option value="">A–Z</option><option value="price">Price ↑</option><option value="-price">Price ↓</option></select></div>
    <div class="row"><label class="mute">Near me:</label><select id="near"><option value="">Anywhere</option>${opts(nodes)}</select>
    <select id="hops"><option value="1">≤1 hop</option><option value="2" selected>≤2 hops</option><option value="3">≤3 hops</option></select></div>
    <div class="grid" id="prod"></div></div>
    <div><div class="card"><h2>Cart</h2><div id="cart"></div>
    <div class="row"><select id="dn">${opts(nodes, "Hostel A")}</select><select id="pm"><option>UPI</option><option>CARD</option><option>COD</option></select></div>
    <label><input type="checkbox" id="ex"> ⚡ Express delivery (priority)</label><br><br><button id="buy">Place order</button></div>
    <div class="card" style="margin-top:16px"><h2>My orders</h2><div id="orders" class="grid" style="grid-template-columns:1fr"></div></div></div></div>`);
  app.append(v);
  const load = async () => {
    const p = new URLSearchParams({ q: $("#q").value, category: $("#cat").value, max: $("#mx").value, sort: $("#sort").value });
    if ($("#near").value) { p.set("near", $("#near").value); p.set("hops", $("#hops").value); }
    products = await api("/products?" + p);
    $("#prod").innerHTML = products.map(x => `<div class="item"><b>${esc(x.name)}</b><span class="mute">${esc(x.shop_name)} · ${esc(x.node)}</span>
      <span class="price">${inr(x.price)}</span><span class="mute">${x.stock} left</span>
      <div class="row"><button data-add="${x.id}" ${x.stock ? "" : "disabled"}>Add</button><button class="sec" data-cmp="${esc(x.name)}">Compare</button></div></div>`).join("") || "<p class='mute'>No products found.</p>";
  };
  const drawCart = () => {
    const rows = Object.entries(cart).map(([id, q]) => { const p = products.find(x => x.id == id) || cartMeta[id]; return `<div class="row">${q}× ${esc(p.name)} <span class="mute">${inr(p.price * q)}</span> <button class="sec" data-rm="${id}">✕</button></div>`; });
    const total = Object.entries(cart).reduce((s, [id, q]) => s + (cartMeta[id].price * q), 0);
    $("#cart").innerHTML = rows.join("") + (rows.length ? `<b>Total ${inr(total)}</b>` : "<p class='mute'>Empty</p>");
  };
  const loadOrders = async () => { $("#orders").innerHTML = (await api("/orders")).map(o => orderCard(o)).join("") || "<p class='mute'>No orders yet.</p>"; };
  const cartMeta = {};
  $("#q").oninput = async () => { $("#sg").innerHTML = (await api("/suggest?q=" + encodeURIComponent($("#q").value))).map(w => `<option value="${w}">`).join(""); load(); };
  ["cat", "mx", "sort", "near", "hops"].forEach(i => $("#" + i).onchange = load);
  v.addEventListener("click", async (e) => {
    const t = e.target;
    if (t.dataset.add) { const p = products.find(x => x.id == t.dataset.add); cartMeta[p.id] = p; cart[p.id] = (cart[p.id] || 0) + 1; drawCart(); }
    if (t.dataset.rm) { delete cart[t.dataset.rm]; drawCart(); }
    if (t.dataset.cmp) { const r = await api("/compare?name=" + encodeURIComponent(t.dataset.cmp)); toast(r.map(p => `${p.shop_name}: ${inr(p.price)}`).join("  |  ")); }
  });
  $("#buy").onclick = async () => {
    const items = Object.entries(cart).map(([id, qty]) => ({ product_id: +id, qty }));
    const r = await api("/orders", "POST", { items, delivery_node: $("#dn").value, payment_method: $("#pm").value, express: $("#ex").checked });
    cart = {}; drawCart(); toast("Order placed: #" + r.order_ids.join(", #")); load(); loadOrders();
  };
  load(); drawCart(); loadOrders();
  timer = setInterval(loadOrders, 5000);
}

// ---------------------------------------------------------------- vendor
function vendorView() {
  const v = el(`<div class="two"><div class="card"><h2>My products</h2>
    <div class="row"><input id="pn" placeholder="Product name"><input id="pp" type="number" placeholder="Price" style="width:90px"><input id="ps" type="number" placeholder="Stock" style="width:90px"><button id="pa">Add</button></div>
    <table><thead><tr><th>Name</th><th>Price</th><th>Stock</th><th></th></tr></thead><tbody id="pl"></tbody></table></div>
    <div><div class="card"><h2>Sales</h2><div id="sales"></div></div></div></div>
    <div class="card"><h2>Incoming orders</h2><div class="grid" id="vo"></div></div>`);
  app.append(v);
  const act = (o) => ({ PLACED: [["ACCEPTED", "Accept", "ok"], ["REJECTED", "Reject", "bad"]], ACCEPTED: [["READY", "Mark ready", ""]] }[o.status] || [])
    .map(([s, l, c]) => `<button class="${c}" data-st="${s}" data-id="${o.id}">${l}</button>`).join(" ");
  const loadP = async () => {
    $("#pl").innerHTML = (await api("/vendor/products")).map(p => `<tr><td>${esc(p.name)}</td><td><input type="number" value="${p.price}" data-f="price" data-id="${p.id}" style="width:80px"></td>
      <td><input type="number" value="${p.stock}" data-f="stock" data-id="${p.id}" style="width:70px"></td><td><button class="bad" data-del="${p.id}">✕</button></td></tr>`).join("");
  };
  const loadO = async () => {
    $("#vo").innerHTML = (await api("/vendor/orders")).map(o => orderCard(o, `<div class="row">${act(o)}</div>`)).join("") || "<p class='mute'>No orders yet.</p>";
    const s = await api("/vendor/sales");
    $("#sales").innerHTML = `<div class="stat"><b>${inr(s.summary.revenue)}</b>${s.summary.orders} orders</div><p class="mute">Top sellers</p>` + s.top_products.map(t => `<div>${esc(t.name)} — ${t.sold}</div>`).join("");
  };
  v.addEventListener("click", async (e) => {
    const t = e.target;
    if (t.id === "pa") { await api("/vendor/products", "POST", { name: $("#pn").value, price: $("#pp").value, stock: $("#ps").value }); loadP(); }
    if (t.dataset.del) { await api("/vendor/products/" + t.dataset.del, "DELETE"); loadP(); }
    if (t.dataset.st) { await api(`/vendor/orders/${t.dataset.id}/status`, "POST", { status: t.dataset.st }); loadO(); }
  });
  v.addEventListener("change", async (e) => {
    const t = e.target; if (!t.dataset.f) return;
    await api("/vendor/products/" + t.dataset.id, "PUT", { [t.dataset.f]: t.value }); toast("Updated");
  });
  loadP(); loadO(); timer = setInterval(loadO, 5000);
}

// ---------------------------------------------------------------- delivery
function deliveryView() {
  const v = el(`<div class="card"><h2>My deliveries</h2><div class="row"><span id="st"></span><label class="mute">My location:</label><select id="loc">${opts(nodes)}</select><button class="sec" id="setloc">Update</button></div><div class="grid" id="jobs"></div></div>`);
  app.append(v);
  const load = async () => {
    const d = await api("/delivery/jobs");
    $("#st").innerHTML = d.partner.is_available ? '<span class="tag DELIVERED">Available</span>' : '<span class="tag PICKED_UP">Busy</span>';
    $("#loc").value = d.partner.node;
    $("#jobs").innerHTML = d.jobs.map(o => orderCard(o, { ASSIGNED: `<button data-id="${o.id}">Picked up</button>`, PICKED_UP: `<button class="ok" data-id="${o.id}">Delivered</button>` }[o.status] || "")).join("") || "<p class='mute'>No jobs yet. Stay available!</p>";
  };
  v.addEventListener("click", async (e) => {
    if (e.target.id === "setloc") { await api("/delivery/location", "POST", { node: $("#loc").value }); toast("Location updated"); }
    else if (e.target.dataset.id) { await api(`/delivery/orders/${e.target.dataset.id}/advance`, "POST"); load(); }
  });
  load(); timer = setInterval(load, 5000);
}

// ---------------------------------------------------------------- admin
function adminView() {
  const v = el(`<div class="card"><h2>Platform overview</h2><div class="grid" id="stats"></div></div>`);
  const r = el(`<div class="card"><h2>Recent orders</h2><table><thead><tr><th>#</th><th>Status</th><th>Total</th><th>Deliver to</th><th>Created</th></tr></thead><tbody id="rec"></tbody></table></div>`);
  app.append(v, r);
  const load = async () => {
    const s = await api("/admin/stats");
    const box = (l, n) => `<div class="item stat"><b>${n}</b>${l}</div>`;
    $("#stats").innerHTML = box("Users", s.users) + box("Vendors", s.vendors) + box("Riders (free)", `${s.partners} (${s.free_partners})`) + box("Orders", s.orders) + box("Revenue", inr(s.revenue));
    $("#rec").innerHTML = s.recent.map(o => `<tr><td>${o.id}</td><td><span class="tag ${o.status}">${o.status}</span></td><td>${inr(o.total)}</td><td>${esc(o.delivery_node)}</td><td>${o.created_at.slice(0, 19)}</td></tr>`).join("");
  };
  load(); timer = setInterval(load, 5000);
}

boot();
