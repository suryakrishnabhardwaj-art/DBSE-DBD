"""Business logic: search indexes (DSA), routing, delivery assignment."""
import re

from database import execute, query, db
from dsa import BST, Graph, HashTable, MinHeap, Trie

# ---------------------------------------------------------------- campus map
EDGES = [
    ("Main Gate", "Admin Block", 300), ("Main Gate", "Market Street", 200),
    ("Admin Block", "Library", 150), ("Admin Block", "Engineering Block", 250),
    ("Library", "Canteen", 120), ("Library", "Engineering Block", 200),
    ("Canteen", "Hostel A", 200), ("Canteen", "Engineering Block", 180),
    ("Hostel A", "Hostel B", 100), ("Hostel B", "Sports Complex", 220),
    ("Engineering Block", "Sports Complex", 300), ("Market Street", "Medical Center", 150),
    ("Medical Center", "Admin Block", 200),
]
WALK_SPEED_M_PER_MIN = 80
PREP_MINUTES = 5

campus = Graph()
for a, b, w in EDGES:
    campus.add_edge(a, b, w)

# ---------------------------------------------------------------- search indexes
_idx = {}


def _norm(s):
    return re.sub(r"\s+", " ", s.strip().lower())


def _tokens(s):
    return re.findall(r"[a-z0-9]+", s.lower())


def rebuild_indexes():
    rows = query("""SELECT p.*, v.shop_name, v.node FROM products p
                    JOIN vendors v ON v.id = p.vendor_id WHERE p.active = 1""")
    by_id, by_name, words, trie, bst = HashTable(), HashTable(), HashTable(), Trie(), BST()
    for r in rows:
        by_id.put(r["id"], r)
        key = _norm(r["name"])
        by_name.put(key, (by_name.get(key) or []) + [r])
        for t in _tokens(r["name"]):
            trie.insert(t)
            words.put(t, (words.get(t) or []) + [r["id"]])
        bst.insert(r["price"], r["id"])
    _idx.update(by_id=by_id, by_name=by_name, words=words, trie=trie, bst=bst, rows=rows)


def search_products(q="", category="", lo=0, hi=float("inf"), sort="", near=None, hops=None):
    if not _idx:
        rebuild_indexes()
    ids = None
    for tok in _tokens(q):  # prefix match through the trie, then inverted index
        found = set()
        for w in _idx["trie"].words_with_prefix(tok):
            found.update(_idx["words"].get(w) or [])
        ids = found if ids is None else ids & found
    price_ids = set(_idx["bst"].range_query(lo, hi))
    ids = price_ids if ids is None else ids & price_ids
    items = [_idx["by_id"].get(i) for i in ids]
    if category:
        items = [p for p in items if p["category"].lower() == category.lower()]
    if near and hops is not None:
        ok = campus.within_hops(near, int(hops))
        items = [p for p in items if p["node"] in ok]
    key = {"price": lambda p: p["price"], "-price": lambda p: -p["price"]}.get(sort, lambda p: p["name"].lower())
    return sorted(items, key=key)


def suggest(prefix, limit=8):
    if not _idx:
        rebuild_indexes()
    return _idx["trie"].words_with_prefix(prefix.split()[-1] if prefix.split() else "", limit)


def compare(name):
    if not _idx:
        rebuild_indexes()
    return sorted(_idx["by_name"].get(_norm(name)) or [], key=lambda p: p["price"])


# ---------------------------------------------------------------- delivery
def route_info(partner_node, vendor_node, customer_node):
    d1, p1 = campus.shortest_path(partner_node, vendor_node) if partner_node else (0, [vendor_node])
    d2, p2 = campus.shortest_path(vendor_node, customer_node)
    total = d1 + d2
    return {"path": p1 + p2[1:], "to_vendor_m": d1, "to_customer_m": d2, "total_m": total,
            "eta_min": round(total / WALK_SPEED_M_PER_MIN + PREP_MINUTES, 1)}


def assign_pending():
    """Priority queue of READY orders (express first, then oldest) -> nearest free partner."""
    pq = MinHeap()
    for o in query("""SELECT o.*, v.node AS vendor_node FROM orders o JOIN vendors v ON v.id=o.vendor_id
                      WHERE o.status='READY' AND o.partner_id IS NULL"""):
        pq.push((0 if o["express"] else 1, o["created_at"]), o)
    assigned = []
    while pq:
        free = query("SELECT * FROM partners WHERE is_available=1")
        if not free:
            break
        _, order = pq.pop()
        dist, _ = campus.dijkstra(order["vendor_node"])
        best = min(free, key=lambda p: dist[p["node"]])
        with db() as c:
            c.execute("UPDATE partners SET is_available=0 WHERE user_id=?", (best["user_id"],))
            c.execute("UPDATE orders SET partner_id=?, status='ASSIGNED' WHERE id=?", (best["user_id"], order["id"]))
        assigned.append((order["id"], best["user_id"]))
    return assigned


def order_view(o):
    items = query("SELECT name, price, qty FROM order_items WHERE order_id=?", (o["id"],))
    v = query("SELECT shop_name, node FROM vendors WHERE id=?", (o["vendor_id"],), one=True)
    o = dict(o, items=items, shop_name=v["shop_name"], vendor_node=v["node"])
    p = query("SELECT node FROM partners WHERE user_id=?", (o["partner_id"],), one=True) if o["partner_id"] else None
    if o["status"] in ("REJECTED", "DELIVERED"):
        o["route"] = None
    else:
        o["route"] = route_info(p["node"] if p and o["status"] == "ASSIGNED" else None, v["node"], o["delivery_node"])
    return o
