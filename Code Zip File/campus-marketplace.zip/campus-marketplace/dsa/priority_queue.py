"""Binary min-heap priority queue.
Used for: order-processing priority (express first, then oldest) and Dijkstra."""


class MinHeap:
    def __init__(self):
        self._a = []
        self._n = 0  # tie-breaker keeps insertion order stable

    def push(self, priority, item):
        self._a.append((priority, self._n, item))
        self._n += 1
        i = len(self._a) - 1
        while i > 0:
            p = (i - 1) // 2
            if self._a[p][:2] <= self._a[i][:2]:
                break
            self._a[p], self._a[i] = self._a[i], self._a[p]
            i = p

    def pop(self):
        if not self._a:
            raise IndexError("pop from empty heap")
        top = self._a[0]
        last = self._a.pop()
        if self._a:
            self._a[0] = last
            i, n = 0, len(self._a)
            while True:
                l, r, s = 2 * i + 1, 2 * i + 2, i
                if l < n and self._a[l][:2] < self._a[s][:2]:
                    s = l
                if r < n and self._a[r][:2] < self._a[s][:2]:
                    s = r
                if s == i:
                    break
                self._a[s], self._a[i] = self._a[i], self._a[s]
                i = s
        return top[0], top[2]

    def peek(self):
        return self._a[0][0], self._a[0][2]

    def __len__(self):
        return len(self._a)

    def __bool__(self):
        return bool(self._a)
