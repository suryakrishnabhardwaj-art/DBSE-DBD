"""FIFO queue implemented with a singly linked list. Used for BFS (nearby vendors)."""


class _Node:
    __slots__ = ("value", "next")

    def __init__(self, value):
        self.value, self.next = value, None


class Queue:
    def __init__(self):
        self._head = self._tail = None
        self._size = 0

    def enqueue(self, value):
        node = _Node(value)
        if self._tail:
            self._tail.next = node
        else:
            self._head = node
        self._tail = node
        self._size += 1

    def dequeue(self):
        if not self._head:
            raise IndexError("dequeue from empty queue")
        node = self._head
        self._head = node.next
        if not self._head:
            self._tail = None
        self._size -= 1
        return node.value

    def __len__(self):
        return self._size

    def __bool__(self):
        return self._size > 0
