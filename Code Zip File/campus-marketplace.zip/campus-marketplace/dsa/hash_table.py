"""Hash table with separate chaining (djb2 hash) and automatic resizing.
Used for: product-by-name index (price comparison), inverted word index, id lookup."""

_MISSING = object()


class HashTable:
    def __init__(self, capacity=16):
        self._buckets = [[] for _ in range(capacity)]
        self._size = 0

    @staticmethod
    def _hash(key):
        h = 5381
        for ch in str(key):
            h = ((h << 5) + h + ord(ch)) & 0xFFFFFFFF
        return h

    def _idx(self, key):
        return self._hash(key) % len(self._buckets)

    def put(self, key, value):
        bucket = self._buckets[self._idx(key)]
        for pair in bucket:
            if pair[0] == key:
                pair[1] = value
                return
        bucket.append([key, value])
        self._size += 1
        if self._size / len(self._buckets) > 0.75:
            self._resize()

    def get(self, key, default=None):
        for k, v in self._buckets[self._idx(key)]:
            if k == key:
                return v
        return default

    def remove(self, key):
        bucket = self._buckets[self._idx(key)]
        for i, (k, _) in enumerate(bucket):
            if k == key:
                bucket.pop(i)
                self._size -= 1
                return True
        return False

    def _resize(self):
        old = self._buckets
        self._buckets = [[] for _ in range(len(old) * 2)]
        self._size = 0
        for bucket in old:
            for k, v in bucket:
                self.put(k, v)

    def items(self):
        for bucket in self._buckets:
            for k, v in bucket:
                yield k, v

    def __contains__(self, key):
        return self.get(key, _MISSING) is not _MISSING

    def __len__(self):
        return self._size
