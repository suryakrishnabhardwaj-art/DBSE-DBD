"""Trie (prefix tree) for fast product-name auto-complete / prefix search."""


class _Node:
    __slots__ = ("children", "is_word")

    def __init__(self):
        self.children = {}
        self.is_word = False


class Trie:
    def __init__(self):
        self.root = _Node()

    def insert(self, word):
        node = self.root
        for ch in word.lower():
            node = node.children.setdefault(ch, _Node())
        node.is_word = True

    def words_with_prefix(self, prefix, limit=None):
        node = self.root
        for ch in prefix.lower():
            node = node.children.get(ch)
            if node is None:
                return []
        out = []
        self._collect(node, list(prefix.lower()), out, limit)
        return out

    def _collect(self, node, path, out, limit):
        if limit is not None and len(out) >= limit:
            return
        if node.is_word:
            out.append("".join(path))
        for ch in sorted(node.children):
            path.append(ch)
            self._collect(node.children[ch], path, out, limit)
            path.pop()
