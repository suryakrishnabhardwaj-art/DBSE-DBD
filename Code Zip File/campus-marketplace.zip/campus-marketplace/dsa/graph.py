"""Weighted undirected graph of the campus map: Dijkstra shortest path + BFS hops."""
from .priority_queue import MinHeap
from .fifo_queue import Queue


class Graph:
    def __init__(self):
        self.adj = {}

    def add_edge(self, a, b, w):
        self.adj.setdefault(a, []).append((b, w))
        self.adj.setdefault(b, []).append((a, w))

    def nodes(self):
        return sorted(self.adj)

    def dijkstra(self, src):
        dist = {n: float("inf") for n in self.adj}
        prev = {}
        dist[src] = 0
        pq = MinHeap()
        pq.push(0, src)
        while pq:
            d, u = pq.pop()
            if d > dist[u]:
                continue
            for v, w in self.adj[u]:
                nd = d + w
                if nd < dist[v]:
                    dist[v], prev[v] = nd, u
                    pq.push(nd, v)
        return dist, prev

    def shortest_path(self, src, dst):
        dist, prev = self.dijkstra(src)
        if dist.get(dst, float("inf")) == float("inf"):
            return float("inf"), []
        path, cur = [dst], dst
        while cur != src:
            cur = prev[cur]
            path.append(cur)
        return dist[dst], path[::-1]

    def within_hops(self, src, max_hops):
        """BFS using the FIFO queue: all nodes reachable in <= max_hops edges."""
        seen = {src: 0}
        q = Queue()
        q.enqueue(src)
        while q:
            u = q.dequeue()
            if seen[u] == max_hops:
                continue
            for v, _ in self.adj[u]:
                if v not in seen:
                    seen[v] = seen[u] + 1
                    q.enqueue(v)
        return set(seen)
