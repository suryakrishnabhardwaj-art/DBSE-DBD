"""Binary Search Tree keyed on price -> supports fast price-range queries."""


class _Node:
    __slots__ = ("key", "values", "left", "right")

    def __init__(self, key, value):
        self.key, self.values, self.left, self.right = key, [value], None, None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, key, value):
        if self.root is None:
            self.root = _Node(key, value)
            return
        node = self.root
        while True:
            if key == node.key:
                node.values.append(value)
                return
            side = "left" if key < node.key else "right"
            nxt = getattr(node, side)
            if nxt is None:
                setattr(node, side, _Node(key, value))
                return
            node = nxt

    def range_query(self, lo, hi):
        """All values with lo <= key <= hi, in ascending key order."""
        out = []

        def walk(n):
            if n is None:
                return
            if lo < n.key:
                walk(n.left)
            if lo <= n.key <= hi:
                out.extend(n.values)
            if n.key < hi:
                walk(n.right)

        walk(self.root)
        return out
