"""SQLite schema + demo seed data."""
import os
import sqlite3
from contextlib import contextmanager

from werkzeug.security import generate_password_hash

DB_PATH = os.environ.get("CAMPUS_DB", os.path.join(os.path.dirname(__file__), "campus.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('customer','vendor','delivery','admin'))
);
CREATE TABLE IF NOT EXISTS vendors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  shop_name TEXT NOT NULL,
  category TEXT NOT NULL,
  node TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vendor_id INTEGER NOT NULL REFERENCES vendors(id),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price REAL NOT NULL CHECK(price >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS partners (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  node TEXT NOT NULL,
  is_available INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  vendor_id INTEGER NOT NULL REFERENCES vendors(id),
  partner_id INTEGER REFERENCES users(id),
  delivery_node TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PLACED',
  total REAL NOT NULL,
  express INTEGER NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL,
  payment_status TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f','now'))
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  name TEXT NOT NULL,
  price REAL NOT NULL,
  qty INTEGER NOT NULL
);
"""


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def db():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def query(sql, args=(), one=False):
    with db() as c:
        rows = [dict(r) for r in c.execute(sql, args).fetchall()]
    return (rows[0] if rows else None) if one else rows


def execute(sql, args=()):
    with db() as c:
        return c.execute(sql, args).lastrowid


def init_db(seed=True):
    with db() as c:
        c.executescript(SCHEMA)
        empty = c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
    if seed and empty:
        _seed()


def _seed():
    def user(name, email, pw, role):
        return execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                       (name, email, generate_password_hash(pw), role))

    user("Admin", "admin@campus.edu", "admin123", "admin")
    user("Demo Student", "student@campus.edu", "student123", "customer")
    for i, node in enumerate(["Main Gate", "Hostel B"], 1):
        uid = user(f"Rider {i}", f"rider{i}@campus.edu", "rider123", "delivery")
        execute("INSERT INTO partners(user_id,node) VALUES(?,?)", (uid, node))

    shops = [
        ("Campus Canteen", "canteen@campus.edu", "Food", "Canteen",
         [("Veg Biryani", 90, 40), ("Masala Dosa", 60, 30), ("Samosa", 15, 100), ("Cold Coffee", 50, 50), ("Bottled Water 1L", 20, 80)]),
        ("Fresh Mart", "mart@campus.edu", "Grocery", "Hostel A",
         [("Bottled Water 1L", 18, 120), ("Instant Noodles", 25, 90), ("Biscuits Pack", 30, 70), ("Cold Coffee", 55, 25), ("Fresh Milk 500ml", 28, 40)]),
        ("PaperPlus Stationery", "paper@campus.edu", "Stationery", "Library",
         [("Ruled Notebook", 55, 60), ("Ball Pen (Blue)", 10, 200), ("Graph Sheets Pack", 40, 50), ("Highlighter Set", 90, 30), ("Biscuits Pack", 32, 20)]),
        ("CampusCare Pharmacy", "pharma@campus.edu", "Pharmacy", "Medical Center",
         [("Paracetamol Strip", 25, 100), ("Hand Sanitizer", 45, 60), ("Bandage Roll", 20, 80), ("Glucose Powder", 60, 40), ("Bottled Water 1L", 22, 50)]),
    ]
    for shop, email, cat, node, items in shops:
        uid = user(shop + " Owner", email, "vendor123", "vendor")
        vid = execute("INSERT INTO vendors(user_id,shop_name,category,node) VALUES(?,?,?,?)", (uid, shop, cat, node))
        for name, price, stock in items:
            execute("INSERT INTO products(vendor_id,name,category,price,stock) VALUES(?,?,?,?,?)",
                    (vid, name, cat, price, stock))
