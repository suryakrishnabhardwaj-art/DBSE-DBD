# Multi-Vendor Campus Marketplace & Delivery Platform

A real-time campus marketplace connecting **vendors**, **customers** and **delivery partners**.
Backend: Python + Flask + SQLite. Frontend: vanilla HTML/CSS/JS (no build step).

## Run

```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                      # http://localhost:5000
```
The database (`campus.db`) is created and seeded with demo data on first run.

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Customer | student@campus.edu | student123 |
| Vendor (Canteen) | canteen@campus.edu | vendor123 |
| Vendor (Fresh Mart / PaperPlus / Pharmacy) | mart@ / paper@ / pharma@campus.edu | vendor123 |
| Delivery | rider1@campus.edu, rider2@campus.edu | rider123 |
| Admin | admin@campus.edu | admin123 |

Try it: log in as the student → add items → place an order (tick *Express*) → log in as the vendor
→ Accept → Mark ready → the nearest free rider is auto-assigned → log in as the rider → Picked up → Delivered.

## Features

- **Vendors**: register, manage products/stock/prices, accept/reject orders, sales summary.
- **Customers**: search with auto-complete, filter by category/price/distance, compare prices across vendors,
  multi-vendor cart (split into one order per vendor), simulated UPI/Card/COD payment, live order tracking with route + ETA.
- **Delivery partners**: update location, see assigned jobs, advance order status.
- **Admin**: platform stats and recent orders.

## Data structures & algorithms (`dsa/`, all implemented from scratch)

| Structure | File | Used for |
|---|---|---|
| Hash table (chaining, resizing) | `hash_table.py` | product-by-id lookup, price comparison by name, inverted word index |
| Trie | `trie.py` | search auto-complete / prefix search |
| Binary search tree | `bst.py` | price-range filtering |
| Min-heap priority queue | `priority_queue.py` | order assignment (express first, then oldest) and Dijkstra |
| FIFO queue (linked list) | `fifo_queue.py` | BFS for "vendors near me" |
| Weighted graph + Dijkstra + BFS | `graph.py` | campus map, delivery routes, nearest rider |

## Project layout

```
app.py          Flask REST API (auth, catalogue, orders, vendor, delivery, admin)
services.py     search indexes, routing, delivery assignment
database.py     SQLite schema + seed data
dsa/            data-structure implementations
static/         index.html, style.css, app.js
tests/          unit tests (DSA) + API integration tests
```

## Tests

```bash
python -m unittest discover -s tests -t .
```

## REST API (summary)

`POST /api/register|login|logout` · `GET /api/me|map|vendors|products|suggest|compare`
`POST /api/orders` · `GET /api/orders[/<id>]`
`GET|POST /api/vendor/products` · `PUT|DELETE /api/vendor/products/<id>` · `GET /api/vendor/orders|sales` · `POST /api/vendor/orders/<id>/status`
`GET /api/delivery/jobs` · `POST /api/delivery/location` · `POST /api/delivery/orders/<id>/advance`
`GET /api/admin/stats`

## Notes

Payments are simulated. For production set `SECRET_KEY`, run behind gunicorn, and replace SQLite with PostgreSQL.
