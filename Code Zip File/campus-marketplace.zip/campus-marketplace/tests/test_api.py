import os
import tempfile
import unittest

os.environ["CAMPUS_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

import app as appmod  # noqa: E402


class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = appmod.create_app()

    def client(self, email, pw):
        c = self.app.test_client()
        r = c.post("/api/login", json={"email": email, "password": pw})
        self.assertEqual(r.status_code, 200)
        return c

    def test_search_compare_suggest(self):
        c = self.app.test_client()
        water = c.get("/api/products?q=wat").get_json()
        self.assertEqual(len(water), 3)
        cmp = c.get("/api/compare?name=Bottled Water 1L").get_json()
        self.assertEqual([p["price"] for p in cmp], sorted(p["price"] for p in cmp))
        self.assertIn("noodles", c.get("/api/suggest?q=noo").get_json())
        cheap = c.get("/api/products?max=20").get_json()
        self.assertTrue(all(p["price"] <= 20 for p in cheap))

    def test_full_order_flow(self):
        cust = self.client("student@campus.edu", "student123")
        pid = cust.get("/api/products?q=samosa").get_json()[0]["id"]
        r = cust.post("/api/orders", json={"items": [{"product_id": pid, "qty": 2}],
                                           "delivery_node": "Hostel B", "payment_method": "UPI", "express": True})
        self.assertEqual(r.status_code, 201)
        oid = r.get_json()["order_ids"][0]
        vendor = self.client("canteen@campus.edu", "vendor123")
        for st in ("ACCEPTED", "READY"):
            self.assertEqual(vendor.post(f"/api/vendor/orders/{oid}/status", json={"status": st}).status_code, 200)
        t = cust.get(f"/api/orders/{oid}").get_json()
        self.assertEqual(t["status"], "ASSIGNED")
        self.assertGreater(t["route"]["total_m"], 0)
        rider = self.client("rider2@campus.edu", "rider123")  # starts at Hostel B (nearest to Canteen via Hostel A)
        jobs = rider.get("/api/delivery/jobs").get_json()["jobs"]
        self.assertEqual([j["id"] for j in jobs], [oid])
        self.assertEqual(rider.post(f"/api/delivery/orders/{oid}/advance").get_json()["status"], "PICKED_UP")
        self.assertEqual(rider.post(f"/api/delivery/orders/{oid}/advance").get_json()["status"], "DELIVERED")
        self.assertEqual(cust.get(f"/api/orders/{oid}").get_json()["status"], "DELIVERED")

    def test_stock_and_roles(self):
        cust = self.client("student@campus.edu", "student123")
        pid = cust.get("/api/products?q=samosa").get_json()[0]["id"]
        r = cust.post("/api/orders", json={"items": [{"product_id": pid, "qty": 9999}],
                                           "delivery_node": "Library", "payment_method": "COD"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(cust.get("/api/vendor/products").status_code, 403)
        self.assertEqual(self.app.test_client().get("/api/orders").status_code, 401)


if __name__ == "__main__":
    unittest.main()
