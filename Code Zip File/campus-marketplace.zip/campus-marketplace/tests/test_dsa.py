import unittest

from dsa import BST, Graph, HashTable, MinHeap, Queue, Trie


class TestDSA(unittest.TestCase):
    def test_hash_table(self):
        h = HashTable(4)
        for i in range(100):
            h.put(f"k{i}", i)
        self.assertEqual(len(h), 100)
        self.assertEqual(h.get("k42"), 42)
        self.assertTrue(h.remove("k42"))
        self.assertNotIn("k42", h)

    def test_trie(self):
        t = Trie()
        for w in ["noodles", "notebook", "note", "pen"]:
            t.insert(w)
        self.assertEqual(t.words_with_prefix("no"), ["noodles", "note", "notebook"])
        self.assertEqual(t.words_with_prefix("x"), [])

    def test_bst_range(self):
        b = BST()
        for i, p in enumerate([50, 20, 70, 20, 90, 10]):
            b.insert(p, i)
        self.assertEqual(sorted(b.range_query(20, 70)), [0, 1, 2, 3])

    def test_heap_order(self):
        h = MinHeap()
        for p in [5, 1, 4, 1, 3]:
            h.push(p, p)
        self.assertEqual([h.pop()[0] for _ in range(5)], [1, 1, 3, 4, 5])

    def test_queue_fifo(self):
        q = Queue()
        for i in range(3):
            q.enqueue(i)
        self.assertEqual([q.dequeue() for _ in range(3)], [0, 1, 2])

    def test_dijkstra_and_bfs(self):
        g = Graph()
        for a, b, w in [("A", "B", 1), ("B", "C", 1), ("A", "C", 5), ("C", "D", 2)]:
            g.add_edge(a, b, w)
        self.assertEqual(g.shortest_path("A", "D"), (4, ["A", "B", "C", "D"]))
        self.assertEqual(g.within_hops("A", 1), {"A", "B", "C"})


if __name__ == "__main__":
    unittest.main()
