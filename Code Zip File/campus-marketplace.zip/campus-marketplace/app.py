"""Multi-Vendor Campus Marketplace & Delivery Platform - Flask REST API."""
import os
from functools import wraps

from flask import Flask, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

import services as svc
from database import db, execute, init_db, query

app = Flask(__name__, static_folder="static", static_url_path="")
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

VENDOR_FLOW = {"PLACED": ["ACCEPTED", "REJECTED"], "ACCEPTED": ["READY"]}
DELIVERY_FLOW = {"ASSIGNED": "PICKED_UP", "PICKED_UP": "DELIVERED"}


def err(msg, code=400):
    return jsonify(error=msg), code


def auth(*roles):
    def deco(fn):
        @wraps(fn)
        def inner(*a, **kw):
            if "uid" not in session:
                return err("login required", 401)
            if roles and session["role"] not in roles:
                return err("forbidden", 403)
            return fn(*a, **kw)
        return inner
    return deco


def my_vendor():
    return query("SELECT * FROM vendors WHERE user_id=?", (session["uid"],), one=True)


@app.get("/")
def home():
    return app.send_static_file("index.html")


# ------------------------------------------------------------------ auth
@app.post("/api/register")
def register():
    d = request.get_json(force=True)
    role = d.get("role")
    if role not in ("customer", "vendor", "delivery"):
        return err("invalid role")
    if not all(d.get(k) for k in ("name", "email", "password")) or len(d["password"]) < 6:
        return err("name, email and password (min 6 chars) required")
    if query("SELECT 1 FROM users WHERE email=?", (d["email"].lower(),), one=True):
        return err("email already registered", 409)
    if d.get("node") not in svc.campus.nodes() and role != "customer":
        return err("valid campus location required")
    uid = execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                  (d["name"], d["email"].lower(), generate_password_hash(d["password"]), role))
    if role == "vendor":
        if not d.get("shop_name") or not d.get("category"):
            return err("shop_name and category required")
        execute("INSERT INTO vendors(user_id,shop_name,category,node) VALUES(?,?,?,?)",
                (uid, d["shop_name"], d["category"], d["node"]))
    elif role == "delivery":
        execute("INSERT INTO partners(user_id,node) VALUES(?,?)", (uid, d["node"]))
    return jsonify(ok=True), 201


@app.post("/api/login")
def login():
    d = request.get_json(force=True)
    u = query("SELECT * FROM users WHERE email=?", ((d.get("email") or "").lower(),), one=True)
    if not u or not check_password_hash(u["password_hash"], d.get("password") or ""):
        return err("invalid credentials", 401)
    session.update(uid=u["id"], role=u["role"], name=u["name"])
    return jsonify(id=u["id"], name=u["name"], role=u["role"])


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
def me():
    if "uid" not in session:
        return jsonify(user=None)
    return jsonify(user={"id": session["uid"], "name": session["name"], "role": session["role"]})


# ------------------------------------------------------------------ catalogue
@app.get("/api/map")
def campus_map():
    return jsonify(nodes=svc.campus.nodes(), edges=svc.EDGES)


@app.get("/api/vendors")
def vendors():
    return jsonify(query("SELECT id, shop_name, category, node FROM vendors"))


@app.get("/api/products")
def products():
    a = request.args
    items = svc.search_products(
        a.get("q", ""), a.get("category", ""),
        float(a.get("min") or 0), float(a.get("max") or "inf"),
        a.get("sort", ""), a.get("near"), a.get("hops"))
    return jsonify(items)


@app.get("/api/suggest")
def suggest():
    return jsonify(svc.suggest(request.args.get("q", "")))


@app.get("/api/compare")
def compare():
    return jsonify(svc.compare(request.args.get("name", "")))


# ------------------------------------------------------------------ customer
@app.post("/api/orders")
@auth("customer")
def place_order():
    d = request.get_json(force=True)
    node, method = d.get("delivery_node"), d.get("payment_method", "UPI")
    if node not in svc.campus.nodes():
        return err("invalid delivery location")
    if method not in ("UPI", "CARD", "COD"):
        return err("invalid payment method")
    cart = d.get("items") or []
    if not cart:
        return err("cart is empty")
    created = []
    try:
        with db() as c:
            by_vendor = {}
            for it in cart:
                qty = int(it.get("qty", 0))
                p = c.execute("SELECT * FROM products WHERE id=? AND active=1", (it.get("product_id"),)).fetchone()
                if not p or qty < 1:
                    raise ValueError("invalid item in cart")
                if p["stock"] < qty:
                    raise ValueError(f"insufficient stock for {p['name']}")
                c.execute("UPDATE products SET stock = stock - ? WHERE id=?", (qty, p["id"]))
                by_vendor.setdefault(p["vendor_id"], []).append((p, qty))
            for vid, lines in by_vendor.items():
                total = sum(p["price"] * q for p, q in lines)
                cur = c.execute(
                    """INSERT INTO orders(customer_id,vendor_id,delivery_node,total,express,payment_method,payment_status)
                       VALUES(?,?,?,?,?,?,?)""",
                    (session["uid"], vid, node, total, int(bool(d.get("express"))), method,
                     "PENDING" if method == "COD" else "PAID"))
                for p, q in lines:
                    c.execute("INSERT INTO order_items(order_id,product_id,name,price,qty) VALUES(?,?,?,?,?)",
                              (cur.lastrowid, p["id"], p["name"], p["price"], q))
                created.append(cur.lastrowid)
    except ValueError as e:
        return err(str(e))
    svc.rebuild_indexes()
    return jsonify(order_ids=created), 201


@app.get("/api/orders")
@auth("customer")
def my_orders():
    rows = query("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC", (session["uid"],))
    return jsonify([svc.order_view(o) for o in rows])


@app.get("/api/orders/<int:oid>")
@auth("customer", "admin")
def track(oid):
    o = query("SELECT * FROM orders WHERE id=?", (oid,), one=True)
    if not o or (session["role"] == "customer" and o["customer_id"] != session["uid"]):
        return err("order not found", 404)
    return jsonify(svc.order_view(o))


# ------------------------------------------------------------------ vendor
@app.get("/api/vendor/products")
@auth("vendor")
def v_products():
    return jsonify(query("SELECT * FROM products WHERE vendor_id=? AND active=1", (my_vendor()["id"],)))


@app.post("/api/vendor/products")
@auth("vendor")
def v_add():
    d = request.get_json(force=True)
    try:
        price, stock = float(d["price"]), int(d.get("stock", 0))
        assert d.get("name") and price >= 0 and stock >= 0
    except (KeyError, ValueError, AssertionError):
        return err("name, price (>=0) and stock (>=0) required")
    v = my_vendor()
    pid = execute("INSERT INTO products(vendor_id,name,category,price,stock) VALUES(?,?,?,?,?)",
                  (v["id"], d["name"], v["category"], price, stock))
    svc.rebuild_indexes()
    return jsonify(id=pid), 201


@app.put("/api/vendor/products/<int:pid>")
@auth("vendor")
def v_update(pid):
    d = request.get_json(force=True)
    p = query("SELECT * FROM products WHERE id=? AND vendor_id=?", (pid, my_vendor()["id"]), one=True)
    if not p:
        return err("not found", 404)
    price, stock = float(d.get("price", p["price"])), int(d.get("stock", p["stock"]))
    if price < 0 or stock < 0:
        return err("invalid values")
    execute("UPDATE products SET price=?, stock=? WHERE id=?", (price, stock, pid))
    svc.rebuild_indexes()
    return jsonify(ok=True)


@app.delete("/api/vendor/products/<int:pid>")
@auth("vendor")
def v_delete(pid):
    execute("UPDATE products SET active=0 WHERE id=? AND vendor_id=?", (pid, my_vendor()["id"]))
    svc.rebuild_indexes()
    return jsonify(ok=True)


@app.get("/api/vendor/orders")
@auth("vendor")
def v_orders():
    rows = query("SELECT * FROM orders WHERE vendor_id=? ORDER BY id DESC", (my_vendor()["id"],))
    return jsonify([svc.order_view(o) for o in rows])


@app.post("/api/vendor/orders/<int:oid>/status")
@auth("vendor")
def v_status(oid):
    new = (request.get_json(force=True) or {}).get("status")
    o = query("SELECT * FROM orders WHERE id=? AND vendor_id=?", (oid, my_vendor()["id"]), one=True)
    if not o:
        return err("not found", 404)
    if new not in VENDOR_FLOW.get(o["status"], []):
        return err(f"cannot move order from {o['status']} to {new}")
    with db() as c:
        c.execute("UPDATE orders SET status=? WHERE id=?", (new, oid))
        if new == "REJECTED":  # restock
            for it in c.execute("SELECT product_id, qty FROM order_items WHERE order_id=?", (oid,)).fetchall():
                c.execute("UPDATE products SET stock = stock + ? WHERE id=?", (it["qty"], it["product_id"]))
    if new == "READY":
        svc.assign_pending()
    svc.rebuild_indexes()
    return jsonify(ok=True)


@app.get("/api/vendor/sales")
@auth("vendor")
def v_sales():
    vid = my_vendor()["id"]
    s = query("""SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS revenue FROM orders
                 WHERE vendor_id=? AND status NOT IN ('REJECTED')""", (vid,), one=True)
    top = query("""SELECT oi.name, SUM(oi.qty) AS sold FROM order_items oi JOIN orders o ON o.id=oi.order_id
                   WHERE o.vendor_id=? AND o.status!='REJECTED' GROUP BY oi.name ORDER BY sold DESC LIMIT 5""", (vid,))
    return jsonify(summary=s, top_products=top)


# ------------------------------------------------------------------ delivery partner
@app.get("/api/delivery/jobs")
@auth("delivery")
def d_jobs():
    p = query("SELECT * FROM partners WHERE user_id=?", (session["uid"],), one=True)
    rows = query("SELECT * FROM orders WHERE partner_id=? ORDER BY id DESC", (session["uid"],))
    return jsonify(partner=p, jobs=[svc.order_view(o) for o in rows])


@app.post("/api/delivery/location")
@auth("delivery")
def d_location():
    node = (request.get_json(force=True) or {}).get("node")
    if node not in svc.campus.nodes():
        return err("invalid location")
    execute("UPDATE partners SET node=? WHERE user_id=?", (node, session["uid"]))
    return jsonify(ok=True)


@app.post("/api/delivery/orders/<int:oid>/advance")
@auth("delivery")
def d_advance(oid):
    o = query("SELECT * FROM orders WHERE id=? AND partner_id=?", (oid, session["uid"]), one=True)
    if not o or o["status"] not in DELIVERY_FLOW:
        return err("order cannot be advanced", 400)
    new = DELIVERY_FLOW[o["status"]]
    with db() as c:
        c.execute("UPDATE orders SET status=? WHERE id=?", (new, oid))
        if new == "DELIVERED":
            c.execute("UPDATE orders SET payment_status='PAID' WHERE id=?", (oid,))
            c.execute("UPDATE partners SET is_available=1, node=? WHERE user_id=?", (o["delivery_node"], session["uid"]))
    if new == "DELIVERED":
        svc.assign_pending()
    return jsonify(status=new)


# ------------------------------------------------------------------ admin
@app.get("/api/admin/stats")
@auth("admin")
def a_stats():
    one = lambda sql: query(sql, one=True)["n"]
    return jsonify(
        users=one("SELECT COUNT(*) n FROM users"), vendors=one("SELECT COUNT(*) n FROM vendors"),
        partners=one("SELECT COUNT(*) n FROM partners"),
        free_partners=one("SELECT COUNT(*) n FROM partners WHERE is_available=1"),
        orders=one("SELECT COUNT(*) n FROM orders"),
        revenue=query("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status!='REJECTED'", one=True)["n"],
        by_status=query("SELECT status, COUNT(*) AS n FROM orders GROUP BY status"),
        recent=query("SELECT id, status, total, delivery_node, created_at FROM orders ORDER BY id DESC LIMIT 15"))


def create_app():
    init_db()
    svc.rebuild_indexes()
    return app


if __name__ == "__main__":
    create_app()
    app.run(debug=True, port=5000)
